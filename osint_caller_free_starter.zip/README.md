# OSINT CALLER — free-tier starter

A minimal public-source phone-number lookup website plus Telegram bot webhook.

## What it does
- Checks that an input contains 7–15 digits.
- Normalizes the number for display.
- Creates links to public web searches (Google and public Reddit-indexed mentions).
- Telegram bot supports `/start`, `/help`, and `/check +91...`.
- Does **not** identify private subscribers, reveal private personal data, query leaked databases, or claim that a search result is verified.

## Files
- `site/index.html` — static website.
- `worker/worker.js` — Cloudflare Worker API + Telegram webhook.
- `worker/wrangler.toml.example` — starter Worker configuration.

## Deploy website (Netlify free tier)
1. Create a GitHub repository and upload the contents of the `site` folder.
2. In Netlify, import that repository and deploy the site.
3. After deploying the Worker (steps below), edit `site/netlify.toml` and set the `/api/*` proxy target to your Worker URL. Then redeploy.
   - Alternatively, replace the frontend fetch URL `/api/check` in `index.html` with your Worker URL plus `/api/check`, and enable a restrictive CORS origin in production.

## Deploy Worker (Cloudflare free tier)
1. Install Wrangler: `npm install -g wrangler`
2. From the `worker` folder, copy `wrangler.toml.example` to `wrangler.toml`.
3. Run `wrangler login`.
4. Set secrets:
   - `wrangler secret put TELEGRAM_BOT_TOKEN`
   - `wrangler secret put TELEGRAM_WEBHOOK_SECRET`
5. Deploy: `wrangler deploy`

## Create Telegram bot
1. Open Telegram and message the official `@BotFather`.
2. Send `/newbot`, choose a display name and a unique username ending in `bot`.
3. Copy the token from BotFather. Keep it private; never paste it into the website or commit it to GitHub.
4. Store it as the `TELEGRAM_BOT_TOKEN` Worker secret.

## Set Telegram webhook
After deployment, use this URL in a browser, replacing placeholders:
`https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook?url=https://<YOUR-WORKER-SUBDOMAIN>.workers.dev/telegram-webhook&secret_token=<YOUR_WEBHOOK_SECRET>`

Do not share the token publicly. If exposed, revoke it through BotFather and create a new one.

## Netlify proxy
Create `site/netlify.toml` with:
```toml
[[redirects]]
  from = "/api/*"
  to = "https://YOUR-WORKER.workers.dev/api/:splat"
  status = 200
  force = true
```

## Important
- Free-tier quotas and provider terms can change; check current Cloudflare and Netlify limits.
- This starter is a demo, not a caller-ID service. Search results may be unrelated or stale.
- Add authentication, rate limiting, logging minimization, abuse reporting, and a privacy notice before public launch.
