const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
const json = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers: {"content-type":"application/json; charset=utf-8", ...cors}
});
function inspectPhone(value) {
  const raw = String(value || "").trim();
  const digits = raw.replace(/\D/g, "");
  if (digits.length < 7 || digits.length > 15) throw new Error("Enter a phone number containing 7–15 digits.");
  const normalized = (raw.startsWith("+") ? "+" : "") + digits;
  const q = encodeURIComponent('"' + normalized + '"');
  return {
    normalized, digits: digits.length,
    note: "Format check only. Country, carrier, owner identity and caller reputation are not verified by this endpoint.",
    sources: [
      {label:"Search the exact number on the public web",url:"https://www.google.com/search?q="+q},
      {label:"Search public Reddit mentions",url:"https://www.google.com/search?q="+encodeURIComponent('site:reddit.com "'+normalized+'"')},
      {label:"Search public business listings",url:"https://www.google.com/search?q="+encodeURIComponent('"'+normalized+'" business')}
    ]
  };
}
async function telegramUpdate(update, env) {
  const msg = update.message;
  if (!msg || !msg.text) return;
  const chatId = msg.chat.id;
  const text = msg.text.trim();
  let reply;
  if (text === "/start" || text === "/help") {
    reply = "OSINT CALLER\\nSend /check +91XXXXXXXXXX to validate the number format and receive public search links. I do not identify private subscribers or access private databases.";
  } else if (text.startsWith("/check ")) {
    try {
      const result = inspectPhone(text.slice(7));
      reply = `FORMAT CHECK\\nInput: ${result.normalized}\\nDigits: ${result.digits}\\n\\n${result.note}\\n\\nPublic searches:\\n` + result.sources.map(s=>`${s.label}: ${s.url}`).join("\\n");
    } catch(e) { reply = e.message; }
  } else {
    reply = "Use /check +91XXXXXXXXXX. Use /help for guidance.";
  }
  await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
    method:"POST", headers:{"content-type":"application/json"},
    body:JSON.stringify({chat_id:chatId,text:reply,disable_web_page_preview:true})
  });
}
export default {
 async fetch(request, env) {
  const url = new URL(request.url);
  if (request.method === "OPTIONS") return new Response(null,{headers:cors});
  if (url.pathname === "/api/check" && request.method === "POST") {
    try {
      const body = await request.json();
      return json(inspectPhone(body.phone));
    } catch(e) { return json({error:e.message || "Invalid request"},400); }
  }
  if (url.pathname === "/telegram-webhook" && request.method === "POST") {
    if (!env.TELEGRAM_BOT_TOKEN) return json({error:"Bot token is not configured"},500);
    const secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token");
    if (env.TELEGRAM_WEBHOOK_SECRET && secret !== env.TELEGRAM_WEBHOOK_SECRET) return json({error:"Unauthorized"},401);
    await telegramUpdate(await request.json(),env);
    return new Response("ok");
  }
  return new Response("OSINT CALLER API online",{headers:{"content-type":"text/plain"}});
 }
};